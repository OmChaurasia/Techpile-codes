#include<stdio.h>
#include<conio.h>

void main(){
    int num;
    printf("enter the number\n");
    scanf("%d",&num);
    if (num>=0){
        printf("the number is positive");
    }
    else
    {
        printf("the number is negative");
    }
    
}

/*

Output :
enter the number
4
the number is positive
*/