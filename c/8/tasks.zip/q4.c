#include <stdio.h>
#include <conio.h>
void main()
{
    int n = 3;
    int x[n];
    x[0] = 10;
    x[1] = 20;
    x[2] = 30;
    printf("%d ", x[0]);
    printf("%d ", x[1]);
    printf("%d ", x[2]);
}

/*
Output:
10 20 30
*/