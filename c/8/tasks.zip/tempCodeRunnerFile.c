 // printf("Enter the number you want to search : ");
    // scanf("%d",&search);
    // for ( i = 0; i < size; i++)
    // {
    //     if (n[i]==search){
    //         index=i;
    //     }
    // }
    // if (index==-1){
    //     printf("Element not found\n");
    // }
    // else
    // {
    //     printf("Element found at : %d\n",index);
    // }