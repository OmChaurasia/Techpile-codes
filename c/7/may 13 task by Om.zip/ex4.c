#include <stdio.h>
#include <conio.h>
void main()
{
    int i,j;
    for (i = 1; i <= 5; i++)
    {
        for (j = 1; j <= 1; j++)
        {
            printf("%d", i);
        }
        printf("\n");
    }
}
/*
 output:

1
2
3
4
5

*/